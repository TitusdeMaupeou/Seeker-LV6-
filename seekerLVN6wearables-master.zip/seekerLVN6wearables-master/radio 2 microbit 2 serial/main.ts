basic.showLeds(`
    # . . . .
    . . . . .
    . . . . .
    . . . . .
    . . . . .
    `);

//settings
radio.setGroup(2);

input.onButtonPressed(Button.A, () => {
    serial.writeLine('{"msg":"transceiver pressed"}');
});

radio.onDataPacketReceived(() => {
    radio.writeReceivedPacketToSerial()
})


