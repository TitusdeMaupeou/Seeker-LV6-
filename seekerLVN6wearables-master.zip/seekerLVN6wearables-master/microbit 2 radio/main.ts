basic.showLeds(`
    . . . # .
    . . . . .
    . . . . .
    . . . . .
    . . . . .
    `);

let counter = 0;
const identifier = "pieter";
const waiter = 50;

radio.setGroup(2);
radio.setTransmitSerialNumber(true);


input.onButtonPressed(Button.A, () => {
    radio.sendValue("test", counter++);
})

function send(name: string, value: number) {
    radio.sendValue(name, value);
    basic.pause(waiter);
}

function sends(value: string) {
    radio.sendString(value);
    basic.pause(waiter);
}

basic.forever(() => {
    sends(identifier);
    send("temperature", input.temperature());
})